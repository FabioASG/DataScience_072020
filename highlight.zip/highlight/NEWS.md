# highlight 0.5.0

* highlight has been un-orphaned; it won't be resuming active development,
  but I will keep it alive on CRAN in the future.
