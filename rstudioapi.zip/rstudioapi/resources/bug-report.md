
### System details

    RStudio Edition : ${RSTUDIO_EDITION}
    RStudio Version : ${RSTUDIO_VERSION}
    OS Version      : ${OS_VERSION}
    R Version       : ${R_VERSION}

### Steps to reproduce the problem

### Describe the problem in detail

### Describe the behavior you expected

<!-- Depending on the problem, the following may also be helpful

1. The output of sessionInfo() 
2. The R code in question
3. A diagnostics report; see https://support.rstudio.com/hc/en-us/articles/200321257-Running-a-Diagnostics-Report

Thank you for taking the time to file an issue!  -->

