#ifndef STAN_LANG_AST_FUN_
#define STAN_LANG_AST_FUN_

namespace stan {
namespace lang {

/**
 */
}
}  // namespace stan
#endif
