# GauPro 0.2.2

Fixing Valgrind error from 0.2.1

# GauPro 0.2.1

Fixing minor errors from the 0.2.0 version.


# GauPro 0.2.0

Added kernel models that use kernels and trends.

# GauPro 0.1.0

Releasing for the first time.

Accepted by CRAN on 10/11/16
