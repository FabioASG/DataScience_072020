# mlr3filters 0.2.0

## Internal

* Use `private$.calculate` instead of public "calculate" method for Filters 
* switch from Travis to GitHub Actions
* Use Roxygen R6 notation for docs

## Enhancements

* new filter `FilterFindCorrelation` (#62, @mb706)


# mlr3filters 0.1.1.9002

* Use `private$.calculate` instead of public calculate method for Filters 
* rename Filter ID of `FilterFindCorrelation` from `findCorrelation` to `find_correlation`


# mlr3filters 0.1.1.9001

* new filter `FilterFindCorrelation` (#62, @mb706)
* switch from Travis to GitHub Actions


# mlr3filters 0.1.1

* Replace dependency `Metrics` with `mlr3measures`.

# mlr3filters 0.1.0

* Initial CRAN release.
